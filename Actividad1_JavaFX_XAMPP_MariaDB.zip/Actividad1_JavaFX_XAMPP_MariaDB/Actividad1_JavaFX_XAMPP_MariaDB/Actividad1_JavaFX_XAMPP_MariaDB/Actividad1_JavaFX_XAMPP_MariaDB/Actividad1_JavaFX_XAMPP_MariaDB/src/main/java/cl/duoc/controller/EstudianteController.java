package cl.duoc.controller;

import cl.duoc.model.Estudiante;
import cl.duoc.repository.EstudianteRepository;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.sql.SQLException;

public class EstudianteController {
    @FXML private TextField txtNombre;
    @FXML private TextField txtCarrera;
    @FXML private TableView<Estudiante> tabla;
    @FXML private TableColumn<Estudiante, Integer> colId;
    @FXML private TableColumn<Estudiante, String> colNombre;
    @FXML private TableColumn<Estudiante, String> colCarrera;
    @FXML private Label lblEstado;
    private final EstudianteRepository repo = new EstudianteRepository();

    @FXML private void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colCarrera.setCellValueFactory(new PropertyValueFactory<>("carrera"));
        cargar();
    }
    @FXML private void guardar() {
        String nombre = txtNombre.getText().trim();
        String carrera = txtCarrera.getText().trim();
        if (nombre.isBlank() || carrera.isBlank()) {
            lblEstado.setText("Ingrese nombre y carrera."); return;
        }
        try {
            repo.guardar(nombre, carrera);
            txtNombre.clear(); txtCarrera.clear();
            cargar();
            lblEstado.setText("Estudiante guardado correctamente.");
        } catch (SQLException e) { mostrarError(e); }
    }
    @FXML private void cargar() {
        try {
            tabla.setItems(FXCollections.observableArrayList(repo.listar()));
            lblEstado.setText("Datos recuperados desde la base de datos.");
        } catch (SQLException e) { mostrarError(e); }
    }

    @FXML private void eliminar() throws SQLException {
        Estudiante seleccionado = tabla.getSelectionModel().getSelectedItem();
        if (seleccionado == null){
            lblEstado.setText("Elija un estudiante válido para eliminar");
            return;
        }
        int id = seleccionado.getId();
        repo.eliminar(id);
        cargar();
        lblEstado.setText("Estudiante eliminado");

    }

    private void mostrarError(SQLException e) {
        lblEstado.setText("Error de base de datos: " + e.getMessage());
        e.printStackTrace();
    }

    @FXML private void actualizar () throws SQLException {
        Estudiante seleccionado = tabla.getSelectionModel().getSelectedItem();
        if (seleccionado == null){
            lblEstado.setText("Elija un estudiante válido");
            return;
        }
        String nombre = txtNombre.getText();
        String carrera = txtCarrera.getText();
        try {
            repo.actualizar(seleccionado, nombre, carrera);
        } catch (SQLException e) {
            mostrarError(e);
        }
        cargar();
        lblEstado.setText("Estudiante Actualizado");
    }
}
