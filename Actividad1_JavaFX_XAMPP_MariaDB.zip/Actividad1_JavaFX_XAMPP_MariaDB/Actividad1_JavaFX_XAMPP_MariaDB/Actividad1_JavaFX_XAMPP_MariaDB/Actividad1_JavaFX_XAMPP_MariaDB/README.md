# Actividad 1 — JavaFX, XAMPP (MariaDB), MySQL Workbench y Maven

## Requisitos
- JDK 21, IntelliJ IDEA y Maven (integrado en IntelliJ).
- XAMPP con MySQL iniciado (el motor incluido realmente es MariaDB).
- MySQL Workbench conectado al servidor XAMPP (sujeto a compatibilidad de versión).

## Ejecución
1. En XAMPP, iniciar **MySQL**. Apache no es necesario para JDBC.
2. En Workbench, conectar a `127.0.0.1:3306` con credenciales de administrador. Si Workbench no conecta por incompatibilidad con MariaDB, ejecutar `sql/01_crear_bd.sql` en phpMyAdmin o en el cliente mysql de XAMPP.
3. Ejecutar todo `sql/01_crear_bd.sql` una vez.
4. Abrir esta carpeta desde IntelliJ IDEA como proyecto Maven y configurar SDK 21.
5. En ventana Maven: Reload All Maven Projects. Maven descarga MariaDB Connector/J automáticamente.
6. Ejecutar con terminal en la raíz del proyecto: `mvn clean javafx:run` (o tarea `javafx:run` desde Maven en IntelliJ).
7. Agregar dos estudiantes y pulsar Actualizar tabla.
8. Verificar con `USE dsy1102_estudiantes; SELECT * FROM estudiantes;` en Workbench.

## Nota de seguridad
El usuario y contraseña de demostración son solo para laboratorio local. No utilizarlos en producción ni subir credenciales reales a repositorios.

## Problemas comunes
- `Connection refused`: servicio apagado o puerto diferente a 3306.
- `Access denied`: usuario/contraseña o permisos incorrectos.
- `Unknown database`: falta ejecutar script SQL.
- `No suitable driver`: recargar Maven, revisar dependencia o URL JDBC.
- `javafx:run` falla: comprobar JDK 21 y Maven descargado.
- Workbench no conecta pero Java sí: compatibilidad de Workbench con MariaDB; verificar con phpMyAdmin.
