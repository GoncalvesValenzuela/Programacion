-- Ejecutar en MySQL Workbench conectado al servidor MariaDB de XAMPP.
CREATE DATABASE IF NOT EXISTS dsy1102_estudiantes CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- Usuario exclusivo para esta actividad (solo acceso local).
CREATE USER IF NOT EXISTS 'dsy1102'@'localhost' IDENTIFIED BY 'Clase1234!';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE ON dsy1102_estudiantes.* TO 'dsy1102'@'localhost';
USE dsy1102_estudiantes;
CREATE TABLE IF NOT EXISTS estudiantes (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(100) NOT NULL,
 carrera VARCHAR(100) NOT NULL
);
SELECT * FROM estudiantes;
