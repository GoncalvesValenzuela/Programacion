package cl.duoc;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(App.class.getResource("/cl/duoc/estudiantes-view.fxml"));
        Scene scene = new Scene(loader.load(), 700, 460);
        stage.setTitle("DSY1102 - Mi primera base de datos");
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] args) { launch(args); }
}
