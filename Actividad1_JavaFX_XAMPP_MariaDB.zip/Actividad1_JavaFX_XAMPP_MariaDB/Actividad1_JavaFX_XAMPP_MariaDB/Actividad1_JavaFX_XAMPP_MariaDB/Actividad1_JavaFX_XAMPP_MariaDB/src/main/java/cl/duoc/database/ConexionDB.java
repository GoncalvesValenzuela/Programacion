package cl.duoc.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {
    private static final String URL = "jdbc:mariadb://localhost:3306/dsy1102_estudiantes";
    private static final String USUARIO = "dsy1102";
    private static final String CLAVE = "Clase1234!";

    private ConexionDB(){}

    public static Connection conectar () throws SQLException {
        return DriverManager.getConnection(URL,USUARIO,CLAVE);
    }
}
