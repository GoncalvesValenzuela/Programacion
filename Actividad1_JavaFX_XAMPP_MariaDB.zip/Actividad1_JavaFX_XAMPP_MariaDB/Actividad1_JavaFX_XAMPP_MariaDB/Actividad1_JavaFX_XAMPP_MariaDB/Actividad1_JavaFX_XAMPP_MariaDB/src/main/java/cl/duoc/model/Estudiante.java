package cl.duoc.model;

public class Estudiante {
    private final int id;
    private final String nombre;
    private final String carrera;

    public Estudiante(int id, String nombre, String carrera) {
        this.id = id; this.nombre = nombre; this.carrera = carrera;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getCarrera() { return carrera; }
}
