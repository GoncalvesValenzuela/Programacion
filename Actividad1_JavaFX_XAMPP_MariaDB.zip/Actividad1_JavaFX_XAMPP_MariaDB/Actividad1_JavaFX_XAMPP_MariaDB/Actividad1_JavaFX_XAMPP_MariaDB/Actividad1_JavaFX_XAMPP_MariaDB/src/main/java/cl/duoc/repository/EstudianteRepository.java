package cl.duoc.repository;

import cl.duoc.database.ConexionDB;
import cl.duoc.model.Estudiante;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstudianteRepository {

    public void guardar (String nombre,String carrera) throws SQLException{
        String sql = "INSERT INTO estudiantes (nombre,carrera) VALUES (?,?) ";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setString(1,nombre);
            ps.setString(2,carrera);
            ps.executeUpdate();
        }
    }
    public List<Estudiante> listar() throws SQLException{
        List<Estudiante> lista = new ArrayList<>();
        String sql = "SELECT id,nombre,carrera FROM estudiantes ORDER BY id";
        try(Connection conn = ConexionDB.conectar();
        PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()){
            while(rs.next()){
                lista.add(new Estudiante(rs.getInt("id"),rs.getString("nombre"),rs.getString("carrera")));
            }
        }
        return lista;
    }

    public void eliminar (int id) throws SQLException{
        String sql = "DELETE FROM estudiantes WHERE id = ?";
        try(Connection conn = ConexionDB.conectar();
        PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }



    }


}
