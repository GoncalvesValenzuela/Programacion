package Ejercicio_Completo;

public interface Curador {
    void curarAliado(Personaje objetivo);
}
