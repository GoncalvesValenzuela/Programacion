package Ejercicio_Completo;

public class Guerrero extends Personaje{
    public Guerrero(String nombre, int pdv, int poderBase) {
        super(nombre, pdv, poderBase);
    }

    @Override
    public void atacar(Personaje objetivo) {
        System.out.println(nombre+", el guerrero, ataca a "+objetivo.getNombre()+" causando daño físico directo. Daño causado: "+poderBase);
        objetivo.recibirDanio(poderBase);
    }
}
