package Ejercicio_Completo;

public interface LanzadorDeHechizo {
    void lanzarHechizo(Personaje objetivo);
}
