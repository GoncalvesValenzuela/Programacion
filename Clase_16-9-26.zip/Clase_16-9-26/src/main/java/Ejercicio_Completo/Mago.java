package Ejercicio_Completo;

public class Mago extends Personaje implements LanzadorDeHechizo{
    public Mago(String nombre, int pdv, int poderBase) {
        super(nombre, pdv, poderBase);
    }

    @Override
    public void atacar(Personaje objetivo) {
        System.out.println(nombre+", el mago, ataca a "+objetivo.getNombre()+
        " usando su bastón, causando "+poderBase+ " puntos de daño mágico");
        objetivo.recibirDanio(poderBase);
    }

    @Override
    public void lanzarHechizo(Personaje objetivo) {
        System.out.println(nombre+" lanza 'Bola de fuego' contra "+objetivo.getNombre());
        objetivo.recibirDanio(poderBase+10);
    }
}
