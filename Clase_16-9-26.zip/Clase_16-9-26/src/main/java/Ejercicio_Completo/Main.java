package Ejercicio_Completo;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //Creación de personajes

        System.out.println("=== MENU GUERRA DE HEROES ===");
        System.out.println();
        System.out.println("1.- Crear personaje ");
        System.out.println("2.- Combatir ");
        System.out.println("3.- Salir");



    }
}
