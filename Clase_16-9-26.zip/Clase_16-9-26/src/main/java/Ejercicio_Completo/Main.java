package Ejercicio_Completo;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ArrayList<Personaje> personajes = new ArrayList<>();

        int opcion;

        do {

            System.out.println("\n=== MENU GUERRA DE HEROES ===");
            System.out.println("1.- Crear personaje");
            System.out.println("2.- Combatir");
            System.out.println("3.- Salir");

            opcion = leerEntero(sc, "Ingrese opción: ");

            switch (opcion) {

                case 1:

                    int tipo;

                    do {

                        System.out.println("\n=== CREACION DE PERSONAJES ===");
                        System.out.println("1.- Crear Guerrero");
                        System.out.println("2.- Crear Mago");
                        System.out.println("3.- Crear Paladín");
                        System.out.println("4.- Volver al menú principal");

                        tipo = leerEntero(sc, "Ingrese su opción: ");

                        switch (tipo) {

                            case 1:

                                System.out.println("\n=== CREANDO GUERRERO ===");

                                System.out.print("Ingrese nombre del guerrero: ");
                                String nombreGuer = sc.nextLine();

                                int pdvGuer = leerEntero(sc,"Ingrese puntos de vida del guerrero: ");

                                int powGuer = leerEntero(sc,"Ingrese poder base del guerrero: ");

                                Personaje guer1 = new Guerrero(nombreGuer, pdvGuer, powGuer);

                                personajes.add(guer1);

                                System.out.println("Personaje creado con éxito.");

                                break;


                            case 2:

                                System.out.println("\n=== CREANDO MAGO ===");

                                System.out.print("Ingrese nombre del mago: ");
                                String nombreMago = sc.nextLine();

                                int pdvMago = leerEntero(sc,"Ingrese puntos de vida del mago: ");

                                int powMago = leerEntero(sc,"Ingrese poder base del mago: ");

                                Personaje mago1 = new Mago(nombreMago, pdvMago, powMago);

                                personajes.add(mago1);

                                System.out.println("Personaje creado con éxito.");

                                break;


                            case 3:

                                System.out.println("\n=== CREANDO PALADIN ===");

                                System.out.print("Ingrese nombre del paladín: ");
                                String nombrePala = sc.nextLine();

                                int pdvPala = leerEntero(sc,"Ingrese puntos de vida del paladín: ");

                                int powPala = leerEntero(sc,"Ingrese poder base del paladín: ");

                                Personaje pala1 = new Paladin(nombrePala, pdvPala, powPala);

                                personajes.add(pala1);

                                System.out.println("Personaje creado con éxito.");

                                break;


                            case 4:

                                System.out.println("Volviendo al menú principal...");

                                break;


                            default:

                                System.out.println("Debe ingresar una opción válida (1-4).");

                                break;
                        }

                    } while (tipo != 4);

                    // IMPORTANTE:
                    // Este break evita que después de crear/salir
                    // se ejecute automáticamente el case 2.
                    break;


                case 2:

                    combatir(sc, personajes);

                    break;


                case 3:

                    System.out.println("\n=== SALIENDO DEL JUEGO... ===");

                    break;


                default:

                    System.out.println("Elija una opción válida.");

                    break;
            }

        } while (opcion != 3);

        sc.close();
    }


    // ============================================================
    // METODO PARA LEER NUMEROS DE FORMA SEGURA
    // ============================================================

    public static int leerEntero(Scanner sc, String mensaje) {

        while (true) {

            System.out.print(mensaje);

            try {

                return Integer.parseInt(sc.nextLine());

            } catch (NumberFormatException e) {

                System.out.println("Entrada inválida. Debe ingresar un número entero.");
            }
        }
    }


    // ============================================================
    // METODO DE COMBATE
    // ============================================================

    public static void combatir(
            Scanner sc,
            ArrayList<Personaje> personajes) {

        if (personajes.size() < 2) {

            System.out.println("Debe haber al menos 2 personajes para combatir.");

            return;
        }


        // --------------------------------------------------------
        // MOSTRAR PERSONAJES
        // --------------------------------------------------------

        System.out.println("\n=== PERSONAJES DISPONIBLES ===");

        for (int i = 0; i < personajes.size(); i++) {

            Personaje pj = personajes.get(i);

            System.out.println((i + 1)+ ". "+ pj.getNombre() + " | HP: " + pj.getPdv());
        }


        // --------------------------------------------------------
        // SELECCIONAR ATACANTE
        // --------------------------------------------------------

        int opcionAtacante = leerEntero(sc,"\nSeleccione el atacante: ");

        if (opcionAtacante < 1 || opcionAtacante > personajes.size()) {

            System.out.println("Atacante inválido.");

            return;
        }

        Personaje atacante = personajes.get(opcionAtacante - 1);


        // --------------------------------------------------------
        // SELECCIONAR OBJETIVO
        // --------------------------------------------------------

        System.out.println("\n=== SELECCIONE OBJETIVO ===");

        for (int i = 0; i < personajes.size(); i++) {

            Personaje pj = personajes.get(i);

            System.out.println((i + 1) + ". " + pj.getNombre()+ " | HP: " + pj.getPdv());
        }


        int opcionObjetivo = leerEntero(sc,"\nSeleccione el objetivo: ");


        if (opcionObjetivo < 1 ||
                opcionObjetivo > personajes.size()) {

            System.out.println("Objetivo inválido.");

            return;
        }


        // --------------------------------------------------------
        // EVITAR QUE UN PERSONAJE SE ATAQUE A SI MISMO
        // --------------------------------------------------------

        if (opcionAtacante == opcionObjetivo) {

            System.out.println("Un personaje no puede atacarse a sí mismo.");

            return;
        }


        Personaje objetivo = personajes.get(opcionObjetivo - 1);


        // --------------------------------------------------------
        // MOSTRAR ACCIONES
        // --------------------------------------------------------

        System.out.println("\n=== ACCIONES DE "+ atacante.getNombre()+ " ==="
        );

        System.out.println("1. Ataque base");

        int eleccion = 2;

        if (atacante instanceof LanzadorDeHechizo) {

            System.out.println(eleccion + ". Lanzar hechizo");

            eleccion++;
        }

        if (atacante instanceof Curador) {

            System.out.println(eleccion + ". Curar aliado");
        }


        // --------------------------------------------------------
        // SELECCIONAR ACCION
        // --------------------------------------------------------

        int accion = leerEntero(sc,"Seleccione acción: " );


        // --------------------------------------------------------
        // EJECUTAR ACCION
        // --------------------------------------------------------

        if (accion == 1) {

            atacante.atacar(objetivo);

            return;
        }


        if (accion == 2 &&
                atacante instanceof LanzadorDeHechizo) {

            LanzadorDeHechizo lanzador = (LanzadorDeHechizo) atacante;

            lanzador.lanzarHechizo(objetivo);

            return;
        }


        if (accion == 3 &&
                atacante instanceof Curador)
        {

            Curador curador = (Curador) atacante;

            curador.curarAliado(objetivo);

            return;
        }


        System.out.println("Acción inválida.");
    }
}
