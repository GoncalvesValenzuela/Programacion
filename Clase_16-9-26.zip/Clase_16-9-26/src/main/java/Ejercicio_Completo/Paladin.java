package Ejercicio_Completo;

public class Paladin extends Personaje implements Curador, LanzadorDeHechizo{
    public Paladin(String nombre, int pdv, int poderBase) {
        super(nombre, pdv, poderBase);
    }

    @Override
    public void atacar(Personaje objetivo) {
        System.out.println(nombre+", el paladín, ataca con su mazo a: "+objetivo+", causando daño sagrado");
    }

    @Override
    public void curarAliado(Personaje objetivo) {
        System.out.println("Curando al objetivo: "+objetivo);

    }

    @Override
    public void lanzarHechizo(Personaje objetivo) {

    }
}
