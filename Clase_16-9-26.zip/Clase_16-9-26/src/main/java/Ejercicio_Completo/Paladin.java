package Ejercicio_Completo;

public class Paladin extends Personaje implements Curador, LanzadorDeHechizo{
    public Paladin(String nombre, int pdv, int poderBase) {
        super(nombre, pdv, poderBase);
    }

    @Override
    public void atacar(Personaje objetivo) {
        System.out.println(nombre+", el paladín, ataca con su mazo a: "+objetivo.getNombre()+", causando daño sagrado");
        objetivo.recibirDanio(poderBase);
    }

    @Override
    public void curarAliado(Personaje objetivo) {
        System.out.println(nombre+ " cura a : "+objetivo.getNombre()+" 20 puntos de vida");
        objetivo.recibirCura(20);

    }

    @Override
    public void lanzarHechizo(Personaje objetivo) {
        System.out.println(nombre+" lanza castigo divino a: "+objetivo.getNombre());
        objetivo.recibirDanio(15);

    }
}
