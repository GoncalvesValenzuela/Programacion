package Ejercicio_Completo;

public abstract class Personaje {
    protected String nombre;
    protected int pdv;
    protected int poderBase;

    public Personaje(String nombre, int pdv, int poderBase) {
        this.nombre = nombre;
        this.pdv = pdv;
        this.poderBase = poderBase;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPdv() {
        return pdv;
    }

    public int getPoderBase() {
        return poderBase;
    }

    public abstract void atacar(Personaje objetivo);

    public void recibirDanio(int cantidad){
      pdv -= cantidad;
      if (pdv <0){
          pdv = 0;
      }

        System.out.println(nombre + " recibe "+cantidad+" puntos de daño. ");
        if (pdv > 0){
            System.out.println("Vida restante de "+nombre+": "+pdv);
        }else{
            System.out.println(nombre+" recibe daño letal");
        }

    }
    public void recibirCura(int cantidad){
        pdv += cantidad;
        System.out.println(nombre+ " recupera "+cantidad+" puntos de vida.");
        System.out.println("Vida actual de "+nombre+": "+ pdv);
    }


}
