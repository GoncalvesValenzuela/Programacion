package Ejercicio_Completo;

public abstract class Personaje {
    protected String nombre;
    protected int pdv;
    protected int poderBase;

    public Personaje(String nombre, int pdv, int poderBase) {
        this.nombre = nombre;
        this.pdv = pdv;
        this.poderBase = poderBase;
    }

    public abstract void atacar(Personaje objetivo);
    public void recibirDanio(int cantidad){
        if(pdv >= cantidad){
            pdv -= cantidad;
        }else{
            System.out.println("Daño letal, vida no puede bajar de 0");
        }

    }
}
