package Interfaces;

public interface Acuatico {
    void navegar();
}
