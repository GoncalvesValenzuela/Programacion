package Interfaces;

public class Hidroavion extends Vehiculo implements Volador,Acuatico{
    public Hidroavion(String marca) {
        super(marca);
    }

    @Override
    public void encender() {
        System.out.println("Encendiendo el hidroavión "+marca+"...");
        System.out.println("Calentando motores y hélices...");
    }

    @Override
    public void despegar() {
        System.out.println("Hidroavión "+marca+" elevándose hacia los cielos");
    }

    @Override
    public void aterrizar() {
        System.out.println("Hidroavión " +marca+" acuatiza suavemente");
    }

    @Override
    public void navegar() {
        System.out.println("Hidroavión "+marca+" navega sin problemas :D");
    }
}
