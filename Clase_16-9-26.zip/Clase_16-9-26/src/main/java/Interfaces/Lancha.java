package Interfaces;

public class Lancha extends Vehiculo implements Acuatico{
    public Lancha(String marca) {
        super(marca);
    }

    @Override
    public void encender() {
        System.out.println("Lanca "+marca+" está encendiendo motor...");
        System.out.println("VROOOM VROOOM!");
    }

    @Override
    public void navegar() {
        System.out.println("Lancha "+marca+" navega magestuosamente");
    }
}
