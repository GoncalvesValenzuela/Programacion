package Interfaces;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {


        System.out.println("=== 1.- Comportamiento individual ===");

        Hidroavion avion = new Hidroavion("Cessna");
        avion.mostrarIdentidad();
        avion.encender();
        avion.despegar();
        avion.aterrizar();
        avion.navegar();


        System.out.println("\n=== 2.- Creando otro vehículo ===");
        Lancha lancha = new Lancha("YAMAHA V8");
        lancha.mostrarIdentidad();
        lancha.encender();
        lancha.navegar();



        List<Acuatico> catastroNaval = new ArrayList<>();

        catastroNaval.add(avion);
        catastroNaval.add(lancha);

        for(Acuatico objeto : catastroNaval){
            objeto.navegar();
        }


    }
}