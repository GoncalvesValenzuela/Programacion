package Interfaces;

public abstract class Vehiculo {
    protected String marca;

    public Vehiculo(String marca) {
        this.marca = marca;
    }

    public void mostrarIdentidad(){
        System.out.println("Soy un vehículo de la marca: "+marca);

    }

    public abstract void encender();
}
