package Interfaces;

public interface Volador {
    //En las interfaces los métodos son public y abstract por defecto
    void despegar();
    void aterrizar();

}
