package Ejercicio4;

public abstract class Cliente {
    private String rut;
    private String nombre;
    private int edad;
    private double peso;


    public Cliente(String rut, String nombre, int edad, double peso) {
        this.rut = rut;
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;

    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        if(rut.isBlank()) throw new IllegalArgumentException("Rut inválido");
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre.isBlank()) throw new IllegalArgumentException("Nombre Inválido");
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        if(edad < 14 || edad > 100)throw new IllegalArgumentException("Edad Inválida");
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        if (peso <= 0) throw new IllegalArgumentException("Peso inválido");
        this.peso = peso;
    }


    @Override
    public String toString() {
        return "Cliente{" +
                "rut='" + rut + '\'' +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", peso=" + peso +
                '}';
    }
    public abstract double calcularMensualidad();
}



