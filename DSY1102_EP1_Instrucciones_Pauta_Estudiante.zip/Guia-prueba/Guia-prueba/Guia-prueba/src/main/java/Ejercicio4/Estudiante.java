package Ejercicio4;

public class Estudiante extends Cliente implements Promocionable{
    private String institucion;

    public Estudiante(String rut, String nombre, int edad, double peso,  String institucion) {
        super(rut, nombre, edad, peso);
        this.institucion = institucion;
    }

    public String getInstitucion() {
        return institucion;
    }

    public void setInstitucion(String institucion) {
        if(institucion.isBlank())throw new IllegalArgumentException("Institución inválida");
        this.institucion = institucion;
    }

    @Override
    public double calcularMensualidad() {
        return aplicarPromocion();
    }

    @Override
    public boolean tienePromocion() {
        return true;
    }

    @Override
    public double aplicarPromocion() {
        double total = 0;
        if (tienePromocion()) {
            total = 20000* 0.85;

        }
        return total;
    }
}
