package Ejercicio4;

import java.util.ArrayList;
import java.util.Scanner;

public class GestorGimnasio {
    ArrayList<Cliente> clientes;

    public GestorGimnasio() {
        clientes = new ArrayList<>();
    }

    public void registrarCliente(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese rut del cliente: ");
        String rut = sc.nextLine();
        System.out.println("Ingrese nombre cliente: ");
        String nombre = sc.nextLine();
        System.out.println("Ingrese edad del cliente: ");
        int edad = Integer.parseInt(sc.nextLine());
        System.out.println("Ingrese peso del cliente: ");
        double peso = Double.parseDouble(sc.nextLine());

        System.out.println("Ingrese tipo de cliente: ");
        System.out.println("1.- Normal");
        System.out.println("2.- Premium");
        System.out.println("3.- Estudiante");
        int tipo = Integer.parseInt(sc.nextLine());

        switch (tipo){
            case 1:
                Cliente cliente = new Normal(rut,nombre,edad,peso);
                clientes.add(cliente);
                break;
            case 2:
                System.out.println("Tiene entrenador personal?(S/N): ");
                String entrenador = sc.nextLine();

                Premium clientePre= new Premium(rut,nombre,edad,peso);
                clientePre.setEntrenador(entrenador);
                clientes.add (clientePre);
                break;
            case 3:
                System.out.println("Ingrese el nombre de su institución: ");
                String institucion = sc.nextLine();

                Cliente clienteEst = new Estudiante(rut,nombre,edad,peso,institucion);
                clientes.add(clienteEst);
                break;
            default:
                System.out.println("Ingrese una opcion  válida");
                break;

        }
        sc.close();
    }
    public void listadoClientes(){
        for (Cliente cliente : clientes){
            System.out.println(cliente.toString());
        }
    }
    public void busquedaPorNombre(String busqueda){
        int coincidencias = 0;
        for(Cliente cliente: clientes){
            if (busqueda.equalsIgnoreCase(cliente.getNombre())) {
                coincidencias++;
                System.out.println(cliente.toString());
            }
            if (coincidencias == 0){
                System.out.println("No hay coincidencias en el registro");
            }
        }
    }
    public void mensualidades(){
        for (Cliente cliente: clientes){
            System.out.println("Cliente: "+cliente.getNombre()+" ||Mensualidad: "+cliente.calcularMensualidad());
        }

    }
    public void calcularTotal(){
        double total = 0;
        for (Cliente cliente: clientes){
            total += cliente.calcularMensualidad();
        }

    }

}
