package Ejercicio4;

public class Normal extends Cliente{


    public Normal(String rut, String nombre, int edad, double peso) {
        super(rut, nombre, edad, peso);
    }

    @Override
    public double calcularMensualidad() {
        return 25000;
    }
}
