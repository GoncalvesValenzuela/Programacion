package Ejercicio4;

import java.util.Locale;

public class Premium extends Cliente implements Promocionable{
    private boolean entrenador;

    public Premium(String rut, String nombre, int edad, double peso) {
        super(rut, nombre, edad, peso);
        this.entrenador = false;
    }

    public boolean getEntrenador() {
        return entrenador;
    }

    public void setEntrenador(String entrenador) {
        boolean entrenador1 = false;
        if(entrenador.equalsIgnoreCase("s")){
            entrenador1 = true;
        }
        this.entrenador = entrenador1;
    }

    @Override
    public double calcularMensualidad() {
       return aplicarPromocion();
    }

    @Override
    public boolean tienePromocion() {
        return !entrenador;
    }

    @Override
    public double aplicarPromocion() {
        double total = 0;
        if(tienePromocion()){
            total = 40000 + 15000;
        }else{
            total = 40000 * 0.90;
        }
        return total;
    }
}
