package Ejercicio4;

public interface Promocionable {

     boolean tienePromocion();
     double aplicarPromocion();
}
