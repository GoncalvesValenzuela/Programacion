package Ejercicio6;

public class Agua extends Pokemon {
    private boolean combateEnAgua;

    public Agua(String nombre, int nivel, double puntosSalud, boolean combateEnAgua) {
        super(nombre, nivel, puntosSalud);
        this.combateEnAgua = combateEnAgua;
    }

    @Override
    public double calcularPoderCombate() {
        double poderBase = getNivel()*9 + getPuntosSalud()*0.25;
        if(combateEnAgua){
            poderBase = poderBase * 1.15;
        }
        return poderBase;
    }

    @Override
    public String toString() {
        return super.toString()
                + " | Tipo: Agua"
                + " | Combate en agua: "
                +(combateEnAgua ? "Si":"No");

    }
}
