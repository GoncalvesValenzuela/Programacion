package Ejercicio6;

public class Electrico extends Pokemon implements Evolucionable{
    private double voltaje;
    private boolean evolucionHabilitada;

    public Electrico(String nombre, int nivel, double puntosSalud, double voltaje, boolean evolucionHabilitada) {
        super(nombre, nivel, puntosSalud);
        this.voltaje = voltaje;
        this.evolucionHabilitada = false;
    }

    public double getVoltaje() {
        return voltaje;
    }

    public void setVoltaje(double voltaje) {
        if(voltaje <= 0){
            throw new IllegalArgumentException("Voltaje debe ser mayor a 0");
        }
        this.voltaje = voltaje;
    }

    @Override
    public double calcularPoderCombate() {
        return getNivel()*11 + getPuntosSalud()*0.15 + voltaje * 0.05;

    }

    @Override
    public boolean puedeEvolucionar() {
        return evolucionHabilitada;
    }

    @Override
    public void habilitarEvolucion() {
        evolucionHabilitada = true;

    }

    @Override
    public String toString() {
        return super.toString()
                +" | Tipo: Electrico"
                +" | Voltaje: "+voltaje
                +" | Evolucion habilitada: "
                +(evolucionHabilitada ? "Si":"No");
    }
}
