package Ejercicio6;

public interface Evolucionable {
    boolean puedeEvolucionar();
    void habilitarEvolucion();
}
