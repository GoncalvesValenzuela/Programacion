package Ejercicio6;

public class Fuego extends Pokemon implements Evolucionable{
    private boolean llamaPotenciada;
    private boolean evolucionHabilitada;

    public Fuego(String nombre, int nivel, double puntosSalud, boolean llamaPotenciada, boolean evolucionHabilitada) {
        super(nombre, nivel, puntosSalud);
        this.llamaPotenciada = llamaPotenciada;
        this.evolucionHabilitada = false;
    }

    @Override
    public double calcularPoderCombate() {
        double poderBase = getNivel()*10 + getPuntosSalud()*0.20;
        if(llamaPotenciada){
            poderBase = poderBase *1.20;
        }
        return poderBase;
    }

    @Override
    public boolean puedeEvolucionar() {
        return evolucionHabilitada;
    }

    @Override
    public void habilitarEvolucion() {
        evolucionHabilitada = true;
    }

    @Override
    public String toString() {
        return  super.toString()
                +" | Tipo: Fuego"
                +" | LLama Potenciada: "
                +(llamaPotenciada ? "Si":"No")
                +" | Evolucion Habilidad: "
                +(evolucionHabilitada ? "Si":"No");
    }
}
