package Ejercicio6;

import java.util.ArrayList;

public class GestorPokemon {
    private ArrayList<Pokemon> pokemones;

    public GestorPokemon() {
        pokemones = new ArrayList<>();
    }

    public void registrarPokemon(Pokemon pokemon){
        if(pokemon == null){
            throw new IllegalArgumentException("No se puede registrar un pokemon nulo");
        }
        pokemones.add(pokemon);
    }

    public Pokemon buscarPorNombre(String nombre){
        if (nombre == null || nombre.trim().isEmpty()){
            return null;
        }
        for (Pokemon pokemon: pokemones){
            if(pokemon.getNombre().equalsIgnoreCase(nombre.trim())){
                return pokemon;
            }
        }
        return null;
    }
    public void listarPokemones(){
        if (pokemones.isEmpty()){
            System.out.println("No hay pokemon registrados");
            return;
        }
        System.out.println("\n=== Listado de Pokemon ===");
        for (Pokemon pokemon: pokemones){
            System.out.println(pokemon.toString());
        }
    }
}
