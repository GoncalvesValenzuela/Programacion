package Ejercicio6;

public abstract class Pokemon {
    private String nombre;
    private int nivel;
    private double puntosSalud;

    public Pokemon(String nombre, int nivel, double puntosSalud) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.puntosSalud = puntosSalud;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(nombre == null || nombre.trim().isEmpty()){
            throw new IllegalArgumentException("Nombre no puede estar vacio");
        }
        this.nombre = nombre;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        if(nivel < 1 || nivel > 100){
            throw new IllegalArgumentException("El nivel debe estar entre 1 y 100");
        }
        this.nivel = nivel;
    }

    public double getPuntosSalud() {
        return puntosSalud;
    }

    public void setPuntosSalud(int puntosSalud) {
        if(puntosSalud <= 0){
            throw new IllegalArgumentException("PDV deben ser mayores a 0");
        }
        this.puntosSalud = puntosSalud;
    }

    public abstract double calcularPoderCombate();

    @Override
    public String toString() {
        return "Nombre: " + nombre + " | Nivel: " + nivel +   " | PuntosSalud: " + puntosSalud;
    }
}
