package org.example;

public class Administrativo extends Empleado{
    public Administrativo(String nombre, int edad, double sueldoBase) {
        super(nombre, edad, sueldoBase);
    }
}
