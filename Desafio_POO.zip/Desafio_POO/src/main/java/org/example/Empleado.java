package org.example;

public class Empleado {
    protected String nombre;
    protected int edad;
    protected double sueldoBase;

    public Empleado(String nombre, int edad, double sueldoBase) {
        this.nombre = nombre;
        this.edad = edad;
        this.sueldoBase = sueldoBase;
    }

    public double calcularSueldo(){
        return sueldoBase;
    }

    public void mostrarInfo(){
        System.out.println("Nombre: "+nombre);
        System.out.println("Edad: "+edad+" años");
        System.out.println("Sueldo: $"+calcularSueldo());
    }
}
