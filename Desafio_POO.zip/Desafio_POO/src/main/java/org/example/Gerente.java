package org.example;

public class Gerente extends Empleado{
    private double bonoGestion;

    public Gerente(String nombre, int edad, double sueldoBase, double bonoGestion) {
        super(nombre, edad, sueldoBase);
        this.bonoGestion = bonoGestion;
    }

    @Override
    public double calcularSueldo() {
        return super.calcularSueldo();
    }
}
