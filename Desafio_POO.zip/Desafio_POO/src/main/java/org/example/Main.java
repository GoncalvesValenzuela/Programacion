package org.example;

public class Main {
    public static void main(String[] args) {
        Empleado[] empleados = new Empleado[3];

        empleados[0] = new Administrativo(
                "Juan",
                40,
                700000
        );

        empleados[1] = new Vendedor(
                "Pedro",
                24,
                700000,
                150000
        );

        empleados[2] = new Gerente(
                "Ana",
                31,
                1200000,
                300000
        );

        for (Empleado empleado : empleados) {

            empleado.mostrarInfo();

            System.out.println("--------------------");

        }
    }
}