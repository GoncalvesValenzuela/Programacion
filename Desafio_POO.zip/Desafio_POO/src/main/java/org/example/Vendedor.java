package org.example;

public class Vendedor extends Empleado{
    private double comision;

    public Vendedor(String nombre, int edad, double sueldoBase, double comision) {
        super(nombre, edad, sueldoBase);
        this.comision = comision;
    }

    @Override
    public double calcularSueldo() {
        return sueldoBase + comision;
    }
}
