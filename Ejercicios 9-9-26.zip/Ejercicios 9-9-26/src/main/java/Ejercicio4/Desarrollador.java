package Ejercicio4;

public class Desarrollador extends Empleado{
    public Desarrollador(String nombre, double sueldoBase) {
        super(nombre, sueldoBase);
    }

    @Override
    public double calcularSueldo() {
        return sueldoBase*1.20;
    }
}
