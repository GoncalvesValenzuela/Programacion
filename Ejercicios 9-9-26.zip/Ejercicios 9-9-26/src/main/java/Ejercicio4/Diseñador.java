package Ejercicio4;

public class Diseñador extends Empleado{
    public Diseñador(String nombre, double sueldoBase) {
        super(nombre, sueldoBase);
    }

    @Override
    public double calcularSueldo() {
        return sueldoBase*1.15;
    }
}
