package Ejercicio4;

import java.util.ArrayList;

public class Lista {
    private ArrayList<Empleado>lista;

    public Lista (){
        lista = new ArrayList<>();
    }

    public void agregarTrabajador(Empleado empleado){
        lista.add(empleado);
    }

    public void mostrarTrabajadores(){
        for (Empleado empleado:lista){
            System.out.println("----------------------");
            empleado.mostrarInfo();
        }
    }

    public double mostrarTotal(){
        double total = 0;
        for (Empleado empleado:lista){
            total += empleado.calcularSueldo();
        }
        return total;
    }
}
