package Ejercicio4;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Lista lista = new Lista();
        int opcion;
        do{
            System.out.println("\nBIENVENIDO AL REGISTRO DE TRABAJADORES DE GOOGLE");
            System.out.println("1.- Registrar Desarrollador");
            System.out.println("2.- Registrar Diseñador");
            System.out.println("3.- Registrar Soporte TI");
            System.out.println("4.- Mostrar trabajadores registrados");
            System.out.println("5.- Mostrar total sueldos");
            System.out.println("0.- Salir");
            System.out.println("Seleccione opción: ");

            opcion = sc.nextInt();
            sc.nextLine();

            switch(opcion){
                case 1:
                    System.out.println("Ingrese nombre desarrollador: ");
                    String nombreDev = sc.nextLine();
                    System.out.println("Ingrese sueldo desarrollador: ");
                    double sueldoDev = Double.parseDouble(sc.nextLine());
                    lista.agregarTrabajador(new Desarrollador(nombreDev,sueldoDev));
                    break;
                case 2:
                    System.out.println("Ingrese nombre diseñador: ");
                    String nombreDis = sc.nextLine();
                    System.out.println("Ingrese sueldo diseñador: ");
                    double sueldoDis = Double.parseDouble(sc.nextLine());
                    lista.agregarTrabajador(new Diseñador(nombreDis,sueldoDis));
                    break;
                case 3:
                    System.out.println("Ingrese nombre soporte TI: ");
                    String nombreTI = sc.nextLine();
                    System.out.println("Ingrese sueldo soporte TI: ");
                    double sueldoTI = Double.parseDouble(sc.nextLine());
                    lista.agregarTrabajador(new Diseñador(nombreTI,sueldoTI));
                    break;
                case 4:
                    lista.mostrarTrabajadores();
                    break;
                case 5:
                    System.out.println("Total sueldos: $"+lista.mostrarTotal());
                    break;
            }
        }while(opcion != 0);
        sc.close();
    }
}