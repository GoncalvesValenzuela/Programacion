package Ejercicio4;

public class Soporte extends Empleado{
    public Soporte(String nombre, double sueldoBase) {
        super(nombre, sueldoBase);
    }

    @Override
    public double calcularSueldo() {
        return sueldoBase*1.10;
    }
}
