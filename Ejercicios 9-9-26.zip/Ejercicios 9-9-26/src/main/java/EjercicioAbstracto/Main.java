package EjercicioAbstracto;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String metodoPago = "";
        do {
            try {
                System.out.println("Bienvenido al portal de pago");
                System.out.println("Ingrese el monto a cancelar: ");
                int monto = Integer.parseInt(sc.nextLine());

                System.out.println("Ingrese el método de pago deseado \n(Tarjeta,Transferencia,Billetera,0 para salir): ");
                metodoPago = sc.nextLine().toUpperCase();

                switch (metodoPago) {
                    case "TARJETA":
                        Pago pagoTar = new PagoTarjeta(monto);
                        pagoTar.procesarPago();
                        pagoTar.mostrarRecibo();
                        break;
                    case "TRANSFERENCIA":
                        Pago pagoTra = new PagoTransferencia(monto);
                        pagoTra.procesarPago();
                        pagoTra.mostrarRecibo();
                        break;
                    case "BILLETERA":
                        Pago pagoBil = new PagoBillDigital(monto);
                        pagoBil.procesarPago();
                        pagoBil.mostrarRecibo();
                        break;
                    case "0":
                        System.out.println("Gracias por comprar con nosotros");
                        break;
                    default:
                        System.out.println("Ingrese una opción válida");
                        break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Debe ingresar un número entero para el monto");
            }
        }while(!metodoPago.equals("0"));
        sc.close();
    }
}
