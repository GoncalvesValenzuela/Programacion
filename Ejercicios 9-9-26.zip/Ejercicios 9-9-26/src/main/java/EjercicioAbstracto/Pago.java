package EjercicioAbstracto;

public abstract class Pago {
    protected double monto;

    public Pago(double monto) {
        this.monto = monto;
    }
    public abstract void procesarPago();

    public void mostrarRecibo() {
        System.out.println("Recibo generado...");
        System.out.println("Su monto es de: $"+monto);
    }
}
