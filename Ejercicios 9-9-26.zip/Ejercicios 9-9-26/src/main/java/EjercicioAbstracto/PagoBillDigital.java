package EjercicioAbstracto;

public class PagoBillDigital extends Pago{
    public PagoBillDigital(double monto) {
        super(monto);
    }

    @Override
    public void procesarPago() {
        System.out.println("Procesando pago por un monto de $:"+monto+" vía billetera virtual...");
        System.out.println("Pago realizado con éxito :D");
    }
}
