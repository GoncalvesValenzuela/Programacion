package EjercicioAbstracto;

public class PagoTarjeta extends Pago {
    public PagoTarjeta(double monto) {
        super(monto);
    }

    @Override
    public void procesarPago() {
        System.out.println("Procesando pago por un monto de $:"+monto+" con tarjeta de crédito...");
        System.out.println("Pago exitoso :D");
    }
}
