package EjercicioAbstracto;

public class PagoTransferencia extends Pago {

    public PagoTransferencia(double monto) {
        super(monto);
    }

    @Override
    public void procesarPago() {
        System.out.println("Procesando pago por un monto de $:"+monto+" vía transferencia...");
        System.out.println("Pago realizado con éxito :D");
    }
}
