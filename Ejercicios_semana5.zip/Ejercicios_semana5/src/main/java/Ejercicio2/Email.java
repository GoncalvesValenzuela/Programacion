package Ejercicio2;

public class Email extends Notificacion{

    public Email(String destinatario) {
        super(destinatario);
    }

    @Override
    public void enviar() {
        System.out.println("Enviando e-mail a "+destinatario);
    }
}
