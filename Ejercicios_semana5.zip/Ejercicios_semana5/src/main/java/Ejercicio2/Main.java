package Ejercicio2;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<Notificacion>notificaciones = new ArrayList<>();

        notificaciones.add(new Email("Alumno@duocuc.cl"));
        notificaciones.add(new Sms("+56963736845"));
        notificaciones.add(new Whatsapp("@alumno"));

        for(Notificacion notificacion: notificaciones){
            notificacion.enviar();
        }

    }
}
