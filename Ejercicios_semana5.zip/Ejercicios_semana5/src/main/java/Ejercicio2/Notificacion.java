package Ejercicio2;


public class Notificacion {
    protected String destinatario;

    public Notificacion(String destinatario) {
        this.destinatario = destinatario;
    }
    public void enviar(){
        System.out.println("Enviando notificación...");
    }
}
