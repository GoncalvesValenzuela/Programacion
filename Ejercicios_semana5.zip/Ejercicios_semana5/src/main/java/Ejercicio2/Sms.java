package Ejercicio2;

public class Sms extends Notificacion{
    public Sms(String destinatario) {
        super(destinatario);
    }

    @Override
    public void enviar() {
        System.out.println("Enviando sms a "+destinatario);
    }
}
