package Ejercicio2;

public class Whatsapp extends Notificacion{
    public Whatsapp(String destinatario) {
        super(destinatario);
    }

    @Override
    public void enviar() {
        System.out.println("Enviando wsp a "+destinatario);
    }
}
