package Ejercicio3;


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Carrito carrito = new Carrito();

        int opcion;

        do{
            System.out.println("\n===GAMETECH===");
            System.out.println("1.- Comprar videojuego");
            System.out.println("2.- Comprar monitor");
            System.out.println("3.- Comprar teclado");
            System.out.println("4.- Mostrar carrito");
            System.out.println("5.- Mostrar total ");
            System.out.println("0.- Salir");
            System.out.println("Seleccione opción: ");

            opcion = sc.nextInt();
            sc.nextLine();

            switch(opcion){
                case 1:
                    System.out.println("Nombre videojuego: ");
                    String juego = sc.nextLine();
                    System.out.println("Precio: ");
                    double precioJuego = sc.nextDouble();
                    sc.nextLine();

                    carrito.agregarProducto(new Videojuego(juego,precioJuego));
                    break;
                case 2:
                    System.out.println("Nombre monitor: ");
                    String monitor = sc.nextLine();
                    System.out.println("Precio: ");
                    double precioMonitor = sc.nextDouble();
                    sc.nextLine();

                    carrito.agregarProducto(new Videojuego(monitor,precioMonitor));
                    break;
                case 3:
                    System.out.println("Nombre teclado: ");
                    String teclado = sc.nextLine();
                    System.out.println("Precio: ");
                    double precioTeclado = sc.nextDouble();
                    sc.nextLine();

                    carrito.agregarProducto(new Videojuego(teclado,precioTeclado));
                    break;
                case 4:
                    carrito.mostrarProductos();
                    break;
                case 5:
                    System.out.println("El total es de: $"+carrito.calcularTotal());
            }

        }while(opcion != 0);

        System.out.println("Gracias por comprar con nosotros...");
        sc.close();

    }
}
