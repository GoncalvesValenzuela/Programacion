package Ejercicio3;

public class Monitor extends Producto{
    private double descuento;

    public Monitor(String nombre, double precio, double descuento) {
        super(nombre, precio);
        this.descuento = 0.15;
    }
    @Override
    public double calcularPrecio() {
        return super.calcularPrecio() - (super.calcularPrecio() * descuento);
    }

    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Descuento: "+(descuento*100)+"%");
        System.out.println("Precio Final: $"+calcularPrecio());
    }
}
