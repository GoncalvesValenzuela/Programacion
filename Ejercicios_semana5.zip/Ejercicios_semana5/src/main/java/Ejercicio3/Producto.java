package Ejercicio3;

public class Producto {
    protected String nombre;
    protected double precio;

    public Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public double calcularPrecio(){
        return precio;
    }
    public void mostrarInfo(){
        System.out.println("Nombre del producto: "+nombre);
        System.out.println("Precio base: $"+precio);
    }
}

