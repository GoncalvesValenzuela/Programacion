package Ejercicio3;

public class Teclado extends Producto{
    private double descuento;

    public Teclado(String nombre, double precio, double descuento) {
        super(nombre, precio);
        this.descuento = 0.05;
    }

    @Override
    public double calcularPrecio() {
        return super.calcularPrecio() - (super.calcularPrecio() * descuento);
    }

    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Descuento: "+(descuento*100)+"%");
        System.out.println("Precio Final: $"+calcularPrecio());
    }
}
