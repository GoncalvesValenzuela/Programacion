package Ejercicio3;

public class Videojuego extends Producto {
    private double descuento;

    public Videojuego(String nombre, double precio) {
        super(nombre, precio);
        this.descuento = 0.1;
    }

    @Override
    public double calcularPrecio() {
        return super.calcularPrecio() - (super.calcularPrecio()*descuento);
    }

    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Descuento: "+(descuento*100)+"%");
        System.out.println("Precio Final: $"+calcularPrecio());
    }
}
