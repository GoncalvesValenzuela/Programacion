package com.example.formulario;

public class Estudiante {

    private String nombre;
    private String correo;
    private String carrera;

    public Estudiante(String nombre, String correo, String carrera) {
        this.nombre = nombre;
        this.correo = correo;
        this.carrera = carrera;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    @Override
    public String toString() {
        return "Nombre: "+nombre+" |Correo: "+correo+" |Carrera: "+carrera;
    }
}
