package com.example.formulario;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class FormularioController {
    @FXML private TextField txtNombre;
    @FXML private TextField txtCorreo;
    @FXML private Label lblCarrera;
    @FXML private Label lblLimpieza;
    @FXML private SplitMenuButton smbCarrera;
    @FXML private MenuItem opc1;
    @FXML private MenuItem opc2;



    @FXML public void cambioTexto(){
        smbCarrera.setText(opc1.getText());
        lblCarrera.setText(opc1.getText());
    }
    @FXML public void reTexto(){
        smbCarrera.setText((opc2.getText()));
        lblCarrera.setText(opc2.getText());
    }
    @FXML
    public void registrar(){
        String nombre = txtNombre.getText().trim();
        String correo = txtCorreo.getText().trim();
        String carrera = smbCarrera.getText().trim();

        Estudiante estudiante = new Estudiante(nombre,correo,carrera);
        lblLimpieza.setText("Estudiante "+nombre+" Ingresado exitosamente!! :D | Carrera: "+carrera);
    }

    @FXML
    public void limpiar(){
        txtNombre.clear();
        txtCorreo.clear();
        lblCarrera.setText("");
        lblLimpieza.setText("Campos limpiados exitosamente");
        smbCarrera.setText("");

    }


}
