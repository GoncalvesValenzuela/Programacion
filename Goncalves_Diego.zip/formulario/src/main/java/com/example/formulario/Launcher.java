package com.example.formulario;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(FormularioApplication.class, args);
    }
}
