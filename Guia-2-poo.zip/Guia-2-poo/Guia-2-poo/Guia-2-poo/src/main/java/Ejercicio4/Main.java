package Ejercicio4;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        /*              Captura de datos con scanner
        System.out.println("Ingrese nombre titular: ");
        String titular = sc.nextLine();

        System.out.println("Ingrese saldo: ");
        double saldo = sc.nextDouble();

        CuentaBancaria cliente1 = new CuentaBancaria(titular,saldo);
        */

        //datos en constructor.
        CuentaBancaria cliente1 = new CuentaBancaria("Javier",2000000);

        cliente1.mostrarSaldo();


        System.out.println("Ingrese monto a depositar: ");
        double deposito = sc.nextDouble();
        cliente1.depositar(deposito);

        System.out.print("Ingrese monto a retirar: ");
        double retiro = sc.nextDouble();
        cliente1.retirar(retiro);

        sc.close();
    }
}
