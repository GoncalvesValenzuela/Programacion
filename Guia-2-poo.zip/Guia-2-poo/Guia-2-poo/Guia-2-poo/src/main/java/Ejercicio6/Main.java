package Ejercicio6;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Ingrese tipo de motor: ");
        String tipo = sc.nextLine();

        Motor motor1 = new Motor(tipo);

        System.out.println("Ingrese marca del auto: ");
        String marca = sc.nextLine();

        System.out.println("Ingrese modelo del auto: ");
        String modelo = sc.nextLine();

        Auto auto1 = new Auto(marca,modelo,motor1);

        motor1.estadoMotor();
        auto1.arrancar();
        motor1.estadoMotor();

        sc.close();
    }
}
