package Ejercicio6;

public class Motor {
    private String tipo;
    private Boolean estado;


    public Motor(String tipo) {
        this.tipo = tipo;
        this.estado = false;
    }

    public void encender(){
        this.estado = true;
        System.out.println("El motor "+tipo+" se ha encendido correctamente");
    }
    public void estadoMotor(){
        if (estado){
            System.out.println("El motor de tipo "+tipo+" se encuentra encendido");
        }else{
            System.out.println("El motor de tipo "+tipo+" se encuentra apagado");
        }
    }
}
