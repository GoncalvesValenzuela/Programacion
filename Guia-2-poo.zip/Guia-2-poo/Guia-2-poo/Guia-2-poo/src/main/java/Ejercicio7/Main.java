package Ejercicio7;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Biblioteca biblioteca1 = new Biblioteca();
        Scanner sc = new Scanner(System.in);

        for (int i=0 ; i<2;i++){
            int numero = i+1;
        System.out.println("Ingrese nombre del libro n°"+numero+": ");
        String titulo = sc.nextLine();

        System.out.println("Ingrese autor del libro: ");
        String autor = sc.nextLine();


        Libro libro1 = new Libro(titulo,autor);

        biblioteca1.agregarLibro(libro1);}

        biblioteca1.mostrarLibros();
    }
}
