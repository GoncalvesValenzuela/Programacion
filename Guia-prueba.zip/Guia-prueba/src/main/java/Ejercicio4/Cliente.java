package Ejercicio4;

public abstract class Cliente {
    private String rut;
    private String nombre;
    private int edad;
    private double peso;
    private int mensualidad;

    public Cliente(String rut, String nombre, int edad, double peso, int mensualidad) {
        this.rut = rut;
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.mensualidad = mensualidad;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public int getMensualidad() {
        return mensualidad;
    }

    public void setMensualidad(int mensualidad) {
        this.mensualidad = mensualidad;
    }

    public abstract double calcularMensualidad();
}
