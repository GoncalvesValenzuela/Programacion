package Ejercicio4;

public class Estudiante extends Cliente implements Promocionable{
    private String institucion;

    public Estudiante(String rut, String nombre, int edad, double peso, int mensualidad, String institucion) {
        super(rut, nombre, edad, peso, 20000);
        this.institucion = institucion;
    }

    public String getInstitucion() {
        return institucion;
    }

    public void setInstitucion(String institucion) {
        this.institucion = institucion;
    }

    @Override
    public double calcularMensualidad() {
        return aplicarPromocion();
    }

    @Override
    public boolean tienePromocion() {
        return true;
    }

    @Override
    public double aplicarPromocion() {
        double total = 0;
        if (tienePromocion()) {
            total = getMensualidad() * 0.85;

        }
        return total;
    }
}
