package Ejercicio4;

import java.util.ArrayList;

public class GestorGimnasio {
    ArrayList<Cliente> clientes;

    public GestorGimnasio() {
        clientes = new ArrayList<>();
    }
}
