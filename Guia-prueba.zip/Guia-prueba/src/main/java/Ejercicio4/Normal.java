package Ejercicio4;

public class Normal extends Cliente{


    public Normal(String rut, String nombre, int edad, double peso, int mensualidad) {
        super(rut, nombre, edad, peso, 25000);
    }

    @Override
    public double calcularMensualidad() {
        return getMensualidad();
    }
}
