package Ejercicio4;

public class Premium extends Cliente implements Promocionable{
    private boolean entrenador;

    public Premium(String rut, String nombre, int edad, double peso, int mensualidad, boolean entrenador) {
        super(rut, nombre, edad, peso, 40000);
        this.entrenador = entrenador;
    }

    public boolean getEntrenador() {
        return entrenador;
    }

    public void setEntrenador(boolean entrenador) {
        this.entrenador = entrenador;
    }

    @Override
    public double calcularMensualidad() {
       return aplicarPromocion();
    }

    @Override
    public boolean tienePromocion() {
        return !entrenador;
    }

    @Override
    public double aplicarPromocion() {
        double total = 0;
        if(tienePromocion()){
            total = getMensualidad() + 15000;
        }else{
            total = getMensualidad() * 0.90;
        }
        return total;
    }
}
