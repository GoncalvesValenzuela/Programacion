module peluqueria.peluqueria_sandra_beltran {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;

    opens peluqueria.peluqueria_sandra_beltran to javafx.fxml;
    exports peluqueria.peluqueria_sandra_beltran;
    exports peluqueria.peluqueria_sandra_beltran.controller;
    opens peluqueria.peluqueria_sandra_beltran.controller to javafx.fxml;
}