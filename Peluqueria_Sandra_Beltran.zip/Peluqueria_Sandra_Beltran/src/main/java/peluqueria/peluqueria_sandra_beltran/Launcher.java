package peluqueria.peluqueria_sandra_beltran;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(PeluqueriaApp.class, args);
    }
}
