package peluqueria.peluqueria_sandra_beltran;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class PeluqueriaApp extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(PeluqueriaApp.class.getResource("peluqueria-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Peluquería Sandra Beltrán");
        stage.setScene(scene);
        stage.show();
    }
}
