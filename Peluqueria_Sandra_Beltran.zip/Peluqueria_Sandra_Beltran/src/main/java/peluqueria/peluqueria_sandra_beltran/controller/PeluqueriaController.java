package peluqueria.peluqueria_sandra_beltran.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class PeluqueriaController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }
}
