package peluqueria.peluqueria_sandra_beltran.modelo;

public class Cliente {
    private String rut;
    private String nombre;
    private String direccion;
    private int telefono;
    private String email;

    public Cliente(String rut, String nombre, String direccion, int telefono, String email) {
        this.rut = rut;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
    }

}
