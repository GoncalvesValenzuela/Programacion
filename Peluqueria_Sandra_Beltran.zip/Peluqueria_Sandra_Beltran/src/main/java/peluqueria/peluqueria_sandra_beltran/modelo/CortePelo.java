package peluqueria.peluqueria_sandra_beltran.modelo;

import java.time.LocalDate;
import java.time.LocalTime;

public class CortePelo extends Servicio {
    private TipoCorte tipoCorte;
    private boolean incluyePeinadoEspecial;

    public CortePelo(String idServicio, LocalDate fecha, LocalTime hora,
                     String estadoServicio, Cliente cliente, TipoCorte tipoCorte, boolean incluyePeinadoEspecial) {
        super(idServicio, fecha, hora, estadoServicio, cliente);
        this.tipoCorte = tipoCorte;
        this.incluyePeinadoEspecial = incluyePeinadoEspecial;
    }

    public enum TipoCorte {
        Basico,
        Degradado,
        Capas
    }
    @Override
    public double calcularCosto() {
        return 0;
    }

    @Override
    public String getTipoServicio() {
        return "";
    }

    @Override
    public void avanzarEstado() {

    }

    @Override
    public void cancelarServicio() {

    }



}
