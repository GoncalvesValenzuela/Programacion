package peluqueria.peluqueria_sandra_beltran.modelo;

public interface Gestionable {
    void avanzarEstado();
    void cancelarServicio();
}
