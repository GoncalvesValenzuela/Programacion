package peluqueria.peluqueria_sandra_beltran.modelo;

import java.time.LocalDate;
import java.time.LocalTime;

public abstract class Servicio implements Gestionable {

    private String idServicio;
    private LocalDate fecha;
    private LocalTime hora;
    private String estadoServicio;
    private Cliente cliente;

    public Servicio(String idServicio, LocalDate fecha, LocalTime hora, String estadoServicio, Cliente cliente) {
        this.idServicio = idServicio;
        this.fecha = fecha;
        this.hora = hora;
        this.estadoServicio = estadoServicio;
        this.cliente = cliente;
    }

    public String getIdServicio() {
        return idServicio;
    }

    public void setIdServicio(String idServicio) {
        this.idServicio = idServicio;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public String getEstadoServicio() {
        return estadoServicio;
    }

    public void setEstadoServicio(String estadoServicio) {
        this.estadoServicio = estadoServicio;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }


    public abstract double calcularCosto();

    public abstract String getTipoServicio();



}
