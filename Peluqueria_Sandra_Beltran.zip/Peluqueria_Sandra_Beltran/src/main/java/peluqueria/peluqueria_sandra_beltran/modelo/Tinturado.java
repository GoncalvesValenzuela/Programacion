package peluqueria.peluqueria_sandra_beltran.modelo;

import java.time.LocalDate;
import java.time.LocalTime;

public class Tinturado extends Servicio{

    private LargoCabello largoCabello;
    private boolean requiereColoracion;


    public Tinturado(String idServicio, LocalDate fecha, LocalTime hora, String estadoServicio,
                     Cliente cliente, LargoCabello largoCabello, boolean requiereColoracion) {
        super(idServicio, fecha, hora, estadoServicio, cliente);
        this.largoCabello = largoCabello;
        this.requiereColoracion = requiereColoracion;
    }

    public enum LargoCabello{
        corto,
        medio,
        largo,
        extraLargo
    }


    @Override
    public double calcularCosto() {
        return 0;
    }

    @Override
    public String getTipoServicio() {
        return "";
    }

    @Override
    public void avanzarEstado() {

    }

    @Override
    public void cancelarServicio() {

    }
}
