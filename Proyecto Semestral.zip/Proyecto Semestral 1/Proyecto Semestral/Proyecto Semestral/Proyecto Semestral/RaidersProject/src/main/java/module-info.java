module raiders.project.raidersproject {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires com.almasb.fxgl.all;
    requires javafx.media;

    opens raiders.project.raidersproject to javafx.fxml;
    exports raiders.project.raidersproject;
}