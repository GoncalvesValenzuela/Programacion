package raiders.project.raidersproject;

import javafx.animation.Animation;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

import java.net.URL;
import java.util.ResourceBundle;

public class RaidersController implements Initializable {
    @FXML private Label lblEstado;
    @FXML private TextField txtUser;
    @FXML private TextField txtPassword;
    @FXML private PasswordField pwdPassword;
    @FXML private CheckBox cbxPassword;
    @FXML private ImageView imgLogo;
    @FXML private ImageView imgFondo;
    @FXML private Button btnLogin;
    @FXML private Button btnRegister;
    @FXML private Button btnClear;
    @FXML private MediaPlayer reproductor;



    @Override
    public void initialize (URL location, ResourceBundle resources){
        TranslateTransition panTransition = new TranslateTransition(Duration.seconds(10),imgLogo);
        panTransition.setByX(5.0);
        panTransition.setAutoReverse(true);
        panTransition.setCycleCount(Animation.INDEFINITE);
        panTransition.play();

        iniciarMusica();
    }

    private void iniciarMusica() {

        URL archivoMusica = getClass().getResource("/musica.mp3");

        if (archivoMusica == null) {
            System.out.println("Song not found");
            return;
        }
        Media cancion = new Media(archivoMusica.toExternalForm());
        reproductor = new MediaPlayer(cancion);
        reproductor.setVolume(0.07);
        reproductor.setCycleCount(MediaPlayer.INDEFINITE);
        reproductor.play();
    }

    @FXML
    public void limpiar(){
        txtUser.clear();
        txtPassword.clear();
        pwdPassword.clear();
        lblEstado.setText("All fields cleared");

    }
}
