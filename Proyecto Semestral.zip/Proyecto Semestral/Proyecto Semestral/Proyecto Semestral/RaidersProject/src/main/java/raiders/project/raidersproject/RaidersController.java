package raiders.project.raidersproject;

import javafx.animation.Animation;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

import java.net.URL;
import java.util.ResourceBundle;

public class RaidersController implements Initializable {
    @FXML private Label lblEstado;
    @FXML private TextField txtUser;
    @FXML private TextField txtPassword;
    @FXML private PasswordField pwdPassword;
    @FXML private CheckBox cbxPassword;
    @FXML private ImageView imgLogo;
    @FXML private ImageView imgFondo;
    @FXML private Button btnLogin;
    @FXML private Button btnRegister;
    @FXML private Button btnClear;




    @Override
    public void initialize (URL location, ResourceBundle resources){
        TranslateTransition panTransition = new TranslateTransition(Duration.seconds(10),imgFondo);
        panTransition.setByX(30.0);
        panTransition.setByY(15.0);
        panTransition.setAutoReverse(true);
        panTransition.setCycleCount(Animation.INDEFINITE);
        panTransition.play();
    }
    @FXML
    public void limpiar(){
        txtUser.clear();
        txtPassword.clear();
        pwdPassword.clear();
        lblEstado.setText("Campos limpios");

    }
}
