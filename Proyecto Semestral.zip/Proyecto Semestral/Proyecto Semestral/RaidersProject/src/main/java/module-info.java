module raiders.project.raidersproject {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires com.almasb.fxgl.all;

    opens raiders.project.raidersproject to javafx.fxml;
    exports raiders.project.raidersproject;
}