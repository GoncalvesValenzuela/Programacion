package raiders.project.raidersproject;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(RaidersApp.class, args);
    }
}
