package raiders.project.raidersproject;

import javafx.animation.Animation;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

import java.net.URL;
import java.util.ResourceBundle;

public class RaidersController implements Initializable {

    @FXML private ImageView imgFondo;
    @Override
    public void initialize (URL location, ResourceBundle resources){
        TranslateTransition panTransition = new TranslateTransition(Duration.seconds(10),imgFondo);
        panTransition.setByX(30.0);
        panTransition.setByY(15.0);
        panTransition.setAutoReverse(true);
        panTransition.setCycleCount(Animation.INDEFINITE);
        panTransition.play();


    }
}
