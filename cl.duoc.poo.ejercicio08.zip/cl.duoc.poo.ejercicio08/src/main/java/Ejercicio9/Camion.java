package Ejercicio9;

public class Camion extends VehiculoTransporte{
    public Camion(String id) {
        super(id);
    }

    @Override
    public void transportar(String paquete) {
        System.out.println("Transportando '"+paquete+"' vía transporte terrestre en vehículo "+id+"...");
    }
}
