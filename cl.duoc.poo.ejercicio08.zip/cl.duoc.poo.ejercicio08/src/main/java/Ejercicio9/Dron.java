package Ejercicio9;

public class Dron extends VehiculoTransporte{
    public Dron(String id) {
        super(id);
    }

    @Override
    public void transportar(String paquete) {
        System.out.println("Transportando '"+paquete+"' vía transporte aéreo en vehículo "+id+"...");
    }
}
