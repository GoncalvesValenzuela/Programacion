package Ejercicio9;

public class Entrega {
    private String paquete;
    private VehiculoTransporte vehiculo;

    public Entrega(String paquete, VehiculoTransporte vehiculo) {
        this.paquete = paquete;
        this.vehiculo = vehiculo;
    }

    public String getPaquete() {
        return paquete;
    }

    public void setPaquete(String paquete) {
        this.paquete = paquete;
    }

    public VehiculoTransporte getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(VehiculoTransporte vehiculo) {
        this.vehiculo = vehiculo;
    }

    public void realizarEntrega(){
        System.out.println("Iniciando entrega...");
        vehiculo.transportar(paquete);
    }
}
