package Ejercicio9;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        //Validando el paquete
        String paquete;
        while(true) {
            System.out.println("Ingrese nombre paquete: ");
            paquete = sc.nextLine().trim();

            if(paquete.isEmpty()){
                System.out.println("Paquete debe tener nombre!");
            }else{
                break;
            }


        }
        String id;
        while(true) {
            System.out.println("Ingrese id paquete: ");
            id = sc.nextLine().trim();

            if(id.isEmpty()){
                System.out.println("ID no debe estar vacío!");
            }else{
                break;
            }

            int opcion;
            while(true){
                System.out.println("1.- Camion");
                System.out.println("2.- Dron");
                System.out.println("Ingrese opción: ");

                String entrada = sc.nextLine().trim();

                try{
                    opcion = Integer.parseInt(entrada);
                    if (opcion == 1 || opcion == 2){
                        break;
                    }
                }catch (NumberFormatException e){
                    System.out.println("Error, debe ingresar numero entero");
                }
            }

            VehiculoTransporte vehiculo;
            if(opcion == 1){
                vehiculo = new Camion(id);
            }else{
                vehiculo = new Dron(id);
            }
            Entrega entrega = new Entrega(paquete,vehiculo);

            entrega.realizarEntrega();
            System.out.println();
            sc.close();
        }
    }
}
