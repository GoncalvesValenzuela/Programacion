package Ejercicio9;

public abstract class VehiculoTransporte  {
        protected String id;

    public VehiculoTransporte(String id) {
        this.id = id;
    }

    public abstract void transportar(String paquete);
}
