package cl.duoc.poo.ejercicio08;

public class Alien extends Enemigo{
    public Alien(String nombre, int PDV) {
        super(nombre, PDV);
    }

    @Override
    public void atacar() {
        System.out.println(nombre + " ataca utilizando energía alienígena!...");
    }
}
