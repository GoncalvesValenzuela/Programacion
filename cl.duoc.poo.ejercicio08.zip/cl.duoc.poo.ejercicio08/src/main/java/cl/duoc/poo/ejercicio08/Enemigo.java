package cl.duoc.poo.ejercicio08;

public abstract class Enemigo {
    protected String nombre;
    protected int PDV;

    public Enemigo(String nombre, int PDV) {
        this.nombre = nombre;
        this.PDV = PDV;
    }

    public abstract void atacar();


}
