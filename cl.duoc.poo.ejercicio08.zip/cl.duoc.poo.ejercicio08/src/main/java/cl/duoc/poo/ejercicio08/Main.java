package cl.duoc.poo.ejercicio08;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ArrayList<Enemigo> enemigos = new ArrayList<>();

        String nombreRobot;
        while(true) {
            System.out.println("Ingrese el nombre del robot: ");
            nombreRobot = sc.nextLine().trim();

            if (nombreRobot.isEmpty()) {
                System.out.println("Error: Nombre vacío");
            } else if (nombreRobot.length() < 4) {
                System.out.println("Error: Muy chico");

            } else {
                break;
            }
        }
        Enemigo robot = new Robot(nombreRobot,100);

        String nombreAlien;
        while(true) {
            System.out.println("Ingrese el nombre del alien: ");
            nombreAlien = sc.nextLine().trim();

            if(nombreAlien.isEmpty()){
                System.out.println("Error: Nombre vacío");
            }
            else if(nombreAlien.length()<4){
                System.out.println("Muy chico");
            }
            else{
                break;
            }
        }

        Enemigo alien = new Alien(nombreAlien,150);


        String nombreMutante;

        while(true) {
            System.out.println("Ingrese el nombre del mutante: ");
            nombreMutante = sc.nextLine().trim();

            if(nombreMutante.isEmpty()){
                System.out.println("Muy chico");
            }else if(nombreMutante.length() <4 ){
                System.out.println("Muy chico");
            }else{
                break;
            }
        }

        Enemigo mutante = new Mutante(nombreMutante,200);


        enemigos.add(robot);
        enemigos.add(alien);
        enemigos.add(mutante);

        System.out.println("Comienza la oleada!!!");

        for (Enemigo enemigo: enemigos){
            enemigo.atacar();
        }
        sc.close();







    }
}
