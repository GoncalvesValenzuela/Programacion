package cl.duoc.poo.ejercicio08;

public class Mutante extends Enemigo {
    public Mutante(String nombre, int PDV) {
        super(nombre, PDV);
    }

    @Override
    public void atacar() {
        System.out.println(nombre+" ataca realizando un golpe mutante!...");
    }
}