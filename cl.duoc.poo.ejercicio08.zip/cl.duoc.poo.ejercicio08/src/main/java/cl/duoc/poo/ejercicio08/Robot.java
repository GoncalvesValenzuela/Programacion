package cl.duoc.poo.ejercicio08;

public class Robot extends Enemigo {
    public Robot(String nombre, int PDV) {
        super(nombre, PDV);
    }

    @Override
    public void atacar() {
        System.out.println(nombre+ " está atacando... Disparando laser! Pew Pew!");
    }
}
