package Ejercicio_1;

public class Arquero extends Jugador{
    private double reflejos;

    public Arquero(String nombre, int numero, double velocidad, double reflejos) {
        super(nombre, numero, velocidad);
        this.reflejos = reflejos;
    }

    @Override
    public void mostrarInfo(){
        super.mostrarInfo();
        System.out.println("Tipo de jugador: Arquero");
        System.out.println("Precisión de remate: "+reflejos);

    }
}
