package Ejercicio_1;

public class Delantero extends Jugador{
    private double precision_remate;

    public Delantero(String nombre, int numero, double velocidad, double precision_remate) {
        super(nombre, numero, velocidad);
        this.precision_remate = precision_remate;
    }

    @Override
    public void mostrarInfo(){
        super.mostrarInfo();
        System.out.println("Tipo de jugador: Delantero");
        System.out.println("Precisión de remate: "+precision_remate);

    }
}
