package Ejercicio_1;

public class Jugador {
    protected String nombre;
    protected int numero;
    protected double velocidad;

    public Jugador(String nombre, int numero, double velocidad) {
        this.nombre = nombre;
        this.numero = numero;
        this.velocidad = velocidad;
    }

    public void mostrarInfo(){
        System.out.println("=== DATOS DEL JUGADOR ===");
        System.out.println("Nombre: " +nombre);
        System.out.println("Numero:"+numero);
        System.out.println("Velocidad: "+velocidad);
    }
}
