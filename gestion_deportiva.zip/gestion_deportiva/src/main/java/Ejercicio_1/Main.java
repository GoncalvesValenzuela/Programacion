package Ejercicio_1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Ingrese nombre del jugador: ");
        String nombre = sc.nextLine();

        System.out.println("Ingrese numero de jugador: ");
        int numero = Integer.parseInt(sc.nextLine());

        System.out.println("Ingrese velocidad de jugador: ");
        double velocidad = Double.parseDouble(sc.nextLine());

        System.out.println("Ingrese tipo de jugador: ");
        String tipo = sc.nextLine().toUpperCase();

        if (tipo.equals ("DELANTERO")){
            System.out.println("Ingrese precisión de remate: ");
            double precision = Double.parseDouble(sc.nextLine());

            Delantero del1 = new Delantero(nombre,numero,velocidad,precision);
            del1.mostrarInfo();
        }else{
            System.out.println("Ingrese reflejos: ");
            double reflejos = Double.parseDouble(sc.nextLine());

            Arquero arq1 = new Arquero(nombre,numero,velocidad,reflejos);
            arq1.mostrarInfo();
        }

        sc.close();


    }
}
