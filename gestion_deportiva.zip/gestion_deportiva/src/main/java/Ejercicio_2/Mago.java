package Ejercicio_2;

public class Mago extends Personaje {


    public Mago(String nombre) {
        super(nombre);
        this.HP = 50;
        this.daño = 8;
    }

    @Override
    public void atacar(){
        super.atacar();
        System.out.println(nombre+" utiliza 'Bola de fuego'");
    }


}
