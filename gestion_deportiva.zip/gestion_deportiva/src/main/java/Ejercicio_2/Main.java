package Ejercicio_2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Ingrese nombre del Guerrero: ");
        String nombreWar = sc.nextLine();

        Warro war1 = new Warro(nombreWar);

        System.out.println("Ingrese nombre del Mago: ");
        String nombreMago = sc.nextLine();

        Mago mago1 = new Mago(nombreMago);

        System.out.println("=== TURNO DEL GUERRERO ===");
        war1.atacar();
        System.out.println("=== FIN DEL TURNO DEL GUERRERO ===");
        System.out.println();
        System.out.println("=== TURNO DEL MAGO ===");
        mago1.atacar();
        System.out.println("=== FIN DEL TURNO DEL MAGO ===");


    }
}
