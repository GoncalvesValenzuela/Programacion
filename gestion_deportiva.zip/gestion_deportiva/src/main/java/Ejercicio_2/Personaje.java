package Ejercicio_2;

public class Personaje {
    protected String nombre;
    protected int HP;
    protected int daño;

    public Personaje(String nombre) {
        this.nombre = nombre;
    }

    public void atacar(){
        System.out.println(nombre+" canaliza un ataque...");
    }






}
