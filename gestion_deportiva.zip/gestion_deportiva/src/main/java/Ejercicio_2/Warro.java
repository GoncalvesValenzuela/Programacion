package Ejercicio_2;

public class Warro extends Personaje{


    public Warro(String nombre) {
        super(nombre);
        this.HP = 60;
        this.daño = 3;
    }

    @Override
    public void atacar(){
        super.atacar();
        System.out.println(nombre+" utiliza 'Escudazo'");
    }



}
