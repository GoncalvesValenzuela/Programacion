package com.example.calculadora;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class CalculadoraController {

    @FXML
    private Label lblSumar;

    @FXML
    private Label lblRestar;

    @FXML
    private Label lblMultiplicar;

    @FXML
    private Label lblDividir;

    @FXML
    protected Button btnRestar;

    @FXML
    protected Button btnSumar;

    @FXML
    protected Button btnMultiplicar;

    @FXML
    protected Button btnDividir;

    @FXML
    private TextField txtN1;
    @FXML
    private TextField txtN2;

    @FXML
    private double boton1(){
        return Integer.parseInt(txtN1.getText());
    }
    @FXML
    private double boton2(){
        return Integer.parseInt(txtN2.getText());
    }
    @FXML
    private void sumar(){
        double suma = boton1() + boton2();
        lblSumar.setText(String.valueOf(suma));
    }
    @FXML
    private void restar(){
        double resta = boton1() - boton2();
        lblRestar.setText(String.valueOf(resta));
    }
    @FXML
    private void multiplicar(){
        double multiplicacion = boton1() * boton2();
        lblMultiplicar.setText(String.valueOf(multiplicacion));
    }
    @FXML
    private void dividir(){
        double division = boton1() / boton2();
        lblDividir.setText(String.valueOf(division));
    }
}
