package duoc.poo.demo;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class HelloController {
    @FXML
    private Label lblSaludo;

    @FXML
    private Button btnEnviar;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtEdad;

    @FXML
    private void mostrarDatos(){
        String nombre = txtNombre.getText();
        String edad = txtEdad.getText();
        lblSaludo.setText("Hola, "+nombre+" tengo "+edad+" años.");
    }

    @FXML
    private void despedida(){
        lblSaludo.setText("Nos vemos pronto... adios");
    }
}
