module duoc.poo.demo {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;

    opens duoc.poo.demo to javafx.fxml;
    exports duoc.poo.demo;
}